/**
 * EduRisk · main.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Handles:
 *   1. Slider sync
 *   2. ML prediction (calls Python model via /predict endpoint, or uses
 *      a client-side logistic regression approximation as fallback)
 *   3. AI recommendations via OpenRouter (claude-3-haiku)
 *   4. Scroll reveal animations
 *   5. Metrics page counter animation & tab switching
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * NOTE: For local/standalone use (no backend server), this file includes a
 * client-side logistic regression approximation trained on the same coefficients
 * so the demo works purely in the browser.
 *
 * To wire up a real backend, uncomment the fetch('/predict', ...) call and
 * comment out the clientSidePredict() function.
 * 
 * We have included Claude 3 Haiku via OpenRouter for the recommendation engine, 
 * but we can swap in any model that accepts a similar prompt and returns JSON. 
 * Just update the OPENROUTER_MODEL variable and ensure your prompt is well-tuned for the new model's capabilities.
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ── OpenRouter config ────────────────────────────────────────────────────────
// Replace with your OpenRouter API key (https://openrouter.ai/)
const OPENROUTER_API_KEY = "YOUR_OPENROUTER_API_KEY";
const OPENROUTER_MODEL   = "anthropic/claude-3-haiku";

// ── Extracurricular toggle ────────────────────────────────────────────────────
let ecValue = 1;

function setEC(val) {
  ecValue = val;
  document.getElementById("ec_yes").classList.toggle("active", val === 1);
  document.getElementById("ec_no").classList.toggle("active",  val === 0);
}

// ── Slider sync ───────────────────────────────────────────────────────────────
function syncVal(slider, targetId) {
  document.getElementById(targetId).textContent = slider.value;
}

// ── Collect form values ───────────────────────────────────────────────────────
function collectInputs() {
  return {
    attendance:             parseFloat(document.getElementById("attendance").value),
    study_time:             parseFloat(document.getElementById("study_time").value),
    past_scores:            parseFloat(document.getElementById("past_scores").value),
    assignment_completion:  parseFloat(document.getElementById("assignment_completion").value),
    failures:               parseInt  (document.getElementById("failures").value),
    absences:               parseInt  (document.getElementById("absences").value),
    participation:          parseFloat(document.getElementById("participation").value),
    sleep_hours:            parseFloat(document.getElementById("sleep_hours").value),
    extracurricular:        ecValue,
    peer_support:           parseFloat(document.getElementById("peer_support").value),
    motivation_score:       parseFloat(document.getElementById("motivation_score").value),
    resource_usage:         parseFloat(document.getElementById("resource_usage").value),
    model_type:             document.getElementById("model_type").value
  };
}

// ── Client-side logistic regression approximation ─────────────────────────────
// Coefficients derived from the Python logistic regression training run.
// Used when no backend server is available (pure static demo).
const LR_COEFFICIENTS = {
  attendance:            -0.1124,
  study_time:            -0.0712,
  past_scores:           -0.1031,
  assignment_completion: -0.0936,
  failures:               0.6142,
  absences:               0.0617,
  participation:         -0.0409,
  sleep_hours:           -0.0264,
  extracurricular:       -0.0813,
  peer_support:          -0.0411,
  motivation_score:      -0.0421,
  resource_usage:        -0.0277,
};
const LR_INTERCEPT = 0.382;

// StandardScaler stats (mean, std) from Python training
const SCALER_STATS = {
  attendance:            { mean: 74.9,  std: 17.9 },
  study_time:            { mean: 3.51,  std: 1.79 },
  past_scores:           { mean: 64.8,  std: 17.8 },
  assignment_completion: { mean: 71.7,  std: 19.6 },
  failures:              { mean: 0.72,  std: 0.91 },
  absences:              { mean: 5.94,  std: 5.8  },
  participation:         { mean: 60.0,  std: 21.9 },
  sleep_hours:           { mean: 6.79,  std: 1.38 },
  extracurricular:       { mean: 0.60,  std: 0.49 },
  peer_support:          { mean: 64.9,  std: 19.8 },
  motivation_score:      { mean: 59.8,  std: 21.7 },
  resource_usage:        { mean: 54.8,  std: 24.7 },
};

function sigmoid(x) { return 1 / (1 + Math.exp(-x)); }

function clientSidePredict(inputs) {
  let logit = LR_INTERCEPT;
  for (const [key, coef] of Object.entries(LR_COEFFICIENTS)) {
    const scaled = (inputs[key] - SCALER_STATS[key].mean) / SCALER_STATS[key].std;
    logit += coef * scaled;
  }
  const prob = sigmoid(logit);
  return {
    label:       prob >= 0.5 ? "At Risk" : "Not At Risk",
    probability: parseFloat((prob * 100).toFixed(1))
  };
}

// ── Random Forest client-side approximation (rule-based) ─────────────────────
function rfClientPredict(inputs) {
  // A simplified scoring rule that mirrors the RF feature importances
  const riskScore =
    (100 - inputs.attendance)            * 0.22 +
    (10  - inputs.study_time) * 5        * 0.14 +
    (100 - inputs.past_scores)           * 0.20 +
    (100 - inputs.assignment_completion) * 0.18 +
    inputs.failures * 12                         +
    inputs.absences * 1.2                        +
    (100 - inputs.participation)         * 0.08 +
    (10  - inputs.sleep_hours) * 2       * 0.05 +
    (100 - inputs.motivation_score)      * 0.08 +
    (100 - inputs.resource_usage)        * 0.05;

  // Calibrated threshold (maps to ~38% at-risk rate)
  const threshold = 48;
  const probRaw   = sigmoid((riskScore - threshold) / 12);
  return {
    label:       probRaw >= 0.5 ? "At Risk" : "Not At Risk",
    probability: parseFloat((probRaw * 100).toFixed(1))
  };
}

// ── Identify weak areas for recommendation context ───────────────────────────
function getWeakAreas(inputs) {
  const issues = [];
  if (inputs.attendance < 65)            issues.push(`low attendance (${inputs.attendance}%)`);
  if (inputs.study_time < 2)             issues.push(`very low study time (${inputs.study_time} hrs/day)`);
  if (inputs.past_scores < 50)           issues.push(`low past scores (${inputs.past_scores}%)`);
  if (inputs.assignment_completion < 60) issues.push(`poor assignment completion (${inputs.assignment_completion}%)`);
  if (inputs.failures > 1)               issues.push(`${inputs.failures} past course failures`);
  if (inputs.absences > 15)              issues.push(`high absenteeism (${inputs.absences} days)`);
  if (inputs.motivation_score < 40)      issues.push(`very low motivation (${inputs.motivation_score}%)`);
  if (inputs.sleep_hours < 5)            issues.push(`insufficient sleep (${inputs.sleep_hours} hrs)`);
  if (inputs.participation < 40)         issues.push(`low class participation (${inputs.participation}%)`);
  if (inputs.peer_support < 40)          issues.push(`weak peer support network (${inputs.peer_support}%)`);
  return issues.length ? issues : ["general academic underperformance"];
}

// ── Main prediction entry point ───────────────────────────────────────────────
async function runPrediction() {
  const inputs = collectInputs();

  // Show loading state on button
  const btn = document.querySelector(".predict-btn");
  btn.innerHTML = '<span class="btn-label">Analysing…</span><span class="loading-dots"><span></span><span></span><span></span></span>';
  btn.disabled = true;

  // Try backend first; fall back to client-side
  let result;
  try {
    const res = await fetch("/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(inputs),
      signal: AbortSignal.timeout(4000)
    });
    result = await res.json();
  } catch (_) {
    // No backend — use client-side model
    result = inputs.model_type === "lr"
      ? clientSidePredict(inputs)
      : rfClientPredict(inputs);
  }

  // Restore button
  btn.innerHTML = '<span class="btn-label">Run Assessment</span><span class="btn-arrow">→</span>';
  btn.disabled = false;

  displayResult(result, inputs);
  fetchRecommendations(inputs, result);
}

// ── Display result ────────────────────────────────────────────────────────────
function displayResult(result, inputs) {
  const isRisk    = result.label === "At Risk";
  const section   = document.getElementById("result-section");
  const card      = document.getElementById("result-card");
  const badge     = document.getElementById("verdict-badge");
  const probFill  = document.getElementById("prob-fill");
  const probPct   = document.getElementById("prob-pct");

  section.style.display = "block";
  section.classList.add("visible");

  // Reset then animate
  card.classList.remove("risk", "safe");
  badge.classList.remove("risk", "safe");
  probFill.classList.remove("risk", "safe");
  probFill.style.width = "0";

  requestAnimationFrame(() => {
    setTimeout(() => {
      card.classList.add(isRisk ? "risk" : "safe");
      badge.classList.add(isRisk ? "risk" : "safe");
      badge.textContent = isRisk ? "⚠️ At Risk" : "✅ Not At Risk";
      probFill.classList.add(isRisk ? "risk" : "safe");
      probFill.style.width = `${result.probability}%`;
      probPct.textContent = `${result.probability}% risk probability`;
    }, 50);
  });

  section.scrollIntoView({ behavior: "smooth", block: "center" });
}

// ── Fetch AI recommendations via OpenRouter ───────────────────────────────────
async function fetchRecommendations(inputs, result) {
  const recsSection = document.getElementById("recs-section");
  const recsBody    = document.getElementById("recs-body");

  recsSection.style.display = "block";
  recsSection.classList.add("visible");
  recsBody.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';

  const weakAreas = getWeakAreas(inputs);
  const isRisk    = result.label === "At Risk";

  const prompt = `You are a compassionate educational advisor analysing a student's academic profile.

Student data:
- Attendance: ${inputs.attendance}%
- Daily study time: ${inputs.study_time} hours
- Past scores: ${inputs.past_scores}%
- Assignment completion: ${inputs.assignment_completion}%
- Course failures: ${inputs.failures}
- Absences: ${inputs.absences} days
- Class participation: ${inputs.participation}%
- Sleep: ${inputs.sleep_hours} hours/night
- Extracurricular activities: ${inputs.extracurricular ? "Yes" : "No"}
- Peer support: ${inputs.peer_support}%
- Motivation: ${inputs.motivation_score}%
- Resource usage: ${inputs.resource_usage}%

ML Prediction: ${result.label} (${result.probability}% risk probability)
Key concern areas: ${weakAreas.join(", ")}

Give exactly 5 specific, actionable, warm and humanised recommendations for this student. 
${isRisk ? "Focus on interventions that address their biggest risk factors." : "Focus on maintaining momentum and building on their strengths."}

Format EXACTLY as JSON array of 5 objects with keys: "icon" (single emoji), "title" (3-5 words), "detail" (2 sentences, practical advice).
Return ONLY the JSON array, no other text.`;

  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": window.location.href,
        "X-Title": "EduRisk Student Analyser"
      },
      body: JSON.stringify({
        model: OPENROUTER_MODEL,
        messages: [{ role: "user", content: prompt }],
        max_tokens: 800,
        temperature: 0.7
      })
    });

    const data = await response.json();
    const raw  = data.choices?.[0]?.message?.content ?? "";

    // Parse JSON from response
    const jsonMatch = raw.match(/\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error("No JSON array found");
    const recs = JSON.parse(jsonMatch[0]);
    renderRecommendations(recs, isRisk);

  } catch (err) {
    // Graceful fallback recommendations
    console.warn("OpenRouter API call failed, using fallback:", err.message);
    const fallback = generateFallbackRecs(inputs, isRisk);
    renderRecommendations(fallback, isRisk);
  }
}

// ── Render recommendation cards ───────────────────────────────────────────────
function renderRecommendations(recs, isRisk) {
  const recsBody = document.getElementById("recs-body");

  const header = isRisk
    ? `<p style="color:var(--text-muted);font-size:14px;margin-bottom:24px;line-height:1.7;">
        Based on the student's profile, here are targeted interventions to get back on track:
       </p>`
    : `<p style="color:var(--text-muted);font-size:14px;margin-bottom:24px;line-height:1.7;">
        Great news — this student is on a solid path! Here are ways to keep that momentum:
       </p>`;

  const cards = recs.map((rec, i) => `
    <div class="rec-item" style="animation-delay:${i * 0.08}s">
      <div class="rec-icon">${rec.icon}</div>
      <div class="rec-text">
        <strong>${rec.title}</strong><br>
        ${rec.detail}
      </div>
    </div>
  `).join("");

  recsBody.innerHTML = header + cards;
  document.getElementById("recs-section").scrollIntoView({ behavior: "smooth", block: "start" });
}

// ── Fallback recommendations (no API key / network error) ─────────────────────
function generateFallbackRecs(inputs, isRisk) {
  const all = [
    {
      icon: "📅",
      title: "Build a Study Schedule",
      detail: "Block out fixed study sessions at the same time every day to create a consistent routine. Even 45 minutes of focused study beats 3 hours of distracted work — start small and build up."
    },
    {
      icon: "🛌",
      title: "Prioritise Sleep Hygiene",
      detail: "Aim for 7–8 hours of sleep each night — it directly affects memory consolidation and focus the next day. Set a screen-free wind-down period 30 minutes before bed."
    },
    {
      icon: "🤝",
      title: "Join a Study Group",
      detail: "Peer learning reinforces concepts 40% faster than solo study according to educational research. Reach out to classmates in your strongest subject and offer to swap knowledge."
    },
    {
      icon: "✅",
      title: "Tackle Assignments Early",
      detail: "Start assignments the day they're given, even if just for 10 minutes — this breaks the 'blank page' paralysis. Setting micro-deadlines three days before the real one creates breathing room."
    },
    {
      icon: "🎯",
      title: "Set Weekly Learning Goals",
      detail: "Write down one specific, measurable goal each Monday — 'finish Chapter 4 exercises' not 'study more'. Checking off concrete goals builds motivation through visible progress."
    },
    {
      icon: "🧑‍🏫",
      title: "Visit Office Hours",
      detail: "Most students never use office hours — which means those who do get undivided attention from their teacher. Bring your most confusing question from the week and work through it together."
    },
    {
      icon: "📱",
      title: "Use Focus Mode",
      detail: "Enable Do Not Disturb during study blocks and put your phone face-down in another room. Research shows a phone visible on the desk — even silent — reduces cognitive capacity by 10%."
    },
    {
      icon: "🌱",
      title: "Reconnect with Motivation",
      detail: "Write a short paragraph about why this subject or degree matters to you — read it when motivation drops. Connecting daily tasks to a larger 'why' reduces procrastination significantly."
    }
  ];

  // Prioritise based on weak areas
  const prioritised = [];
  if (inputs.attendance < 65)     prioritised.push({ icon:"🏫", title:"Attend Every Class", detail:"Even passive attendance — sitting in class without fully engaging — exposes you to structure and cues your brain for learning. Block classes in your calendar like unmovable appointments." });
  if (inputs.sleep_hours < 5.5)   prioritised.push(all[1]);
  if (inputs.peer_support < 45)   prioritised.push(all[2]);
  if (inputs.assignment_completion < 60) prioritised.push(all[3]);
  if (inputs.motivation_score < 45) prioritised.push(all[7]);

  const combined = [...prioritised, ...all].filter(
    (v, i, arr) => arr.findIndex(x => x.title === v.title) === i
  );
  return combined.slice(0, 5);
}

// ── Scroll reveal ─────────────────────────────────────────────────────────────
function initReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
      } else {
        // Fade out when scrolled away (dynamic blocks)
        if (entry.target.classList.contains("re-hide")) {
          entry.target.classList.remove("visible");
        }
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

  document.querySelectorAll(".reveal").forEach(el => {
    el.classList.add("re-hide");
    observer.observe(el);
  });
}

// ── Metrics tab switching ─────────────────────────────────────────────────────
function switchModel(type) {
  ["lr", "rf"].forEach(t => {
    document.getElementById(`tab_${t}`).classList.toggle("active", t === type);
    document.getElementById(`panel_${t}`).classList.toggle("hidden", t !== type);
  });
  // Re-trigger counter animation for newly visible stats
  animateCounters();
}

// ── Animated stat counters ────────────────────────────────────────────────────
function animateCounters() {
  document.querySelectorAll(".stat-num[data-target]").forEach(el => {
    const target = parseFloat(el.dataset.target);
    const duration = 1200;
    const start = performance.now();
    function frame(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = (target * eased).toFixed(1);
      if (progress < 1) requestAnimationFrame(frame);
      else el.textContent = target.toFixed(1);
    }
    requestAnimationFrame(frame);
  });
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  initReveal();

  // Metrics page counter animation on load
  if (document.querySelector(".stat-num[data-target]")) {
    setTimeout(animateCounters, 400);
  }
});
