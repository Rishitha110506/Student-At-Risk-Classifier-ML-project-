"""
Early At-Risk Student Identifier
Model: Logistic Regression + Random Forest (Binary Classifier)
Dataset: Synthetic Student Performance Dataset (600+ samples)
Features: attendance, study_time, past_scores, assignment_completion,
          failures, absences, participation, sleep_hours, extracurricular,
          peer_support, motivation_score, resource_usage
Label: at_risk (1 = At Risk, 0 = Not At Risk)
"""
# Basic Modules imported
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)

# Modules used for saving models and metrics in the webpages
import pickle
import json
import warnings
warnings.filterwarnings("ignore")

# We apply a fixed seed for reproducibility of the synthetic dataset
np.random.seed(42)
N = 620

# ── Generate synthetic dataset [Taken with reference to IEEE Dataset in Kaggle] ───────────────────────────────────────────────
attendance        = np.clip(np.random.normal(75, 18, N), 0, 100)
study_time        = np.clip(np.random.normal(3.5, 1.8, N), 0, 10)
past_scores       = np.clip(np.random.normal(65, 18, N), 0, 100)
assignment_comp   = np.clip(np.random.normal(72, 20, N), 0, 100)
failures          = np.random.choice([0, 1, 2, 3], N, p=[0.55, 0.25, 0.13, 0.07])
absences          = np.clip(np.random.exponential(6, N), 0, 40).astype(int)
participation     = np.clip(np.random.normal(60, 22, N), 0, 100)
sleep_hours       = np.clip(np.random.normal(6.8, 1.4, N), 3, 10)
extracurricular   = np.random.choice([0, 1], N, p=[0.4, 0.6])
peer_support      = np.clip(np.random.normal(65, 20, N), 0, 100)
motivation_score  = np.clip(np.random.normal(60, 22, N), 0, 100)
resource_usage    = np.clip(np.random.normal(55, 25, N), 0, 100)

# Risk label logic (domain-informed)
risk_score = (
    (100 - attendance)       * 0.22 +
    (10  - study_time) * 5   * 0.14 +
    (100 - past_scores)      * 0.20 +
    (100 - assignment_comp)  * 0.18 +
    failures                 * 12   +
    absences                 * 1.2  +
    (100 - participation)    * 0.08 +
    (10  - sleep_hours) * 2  * 0.05 +
    (100 - motivation_score) * 0.08 +
    (100 - resource_usage)   * 0.05
)

threshold = np.percentile(risk_score, 62)
at_risk = (risk_score > threshold).astype(int)

df = pd.DataFrame({
    "attendance":           attendance.round(1),
    "study_time":           study_time.round(1),
    "past_scores":          past_scores.round(1),
    "assignment_completion": assignment_comp.round(1),
    "failures":             failures,
    "absences":             absences,
    "participation":        participation.round(1),
    "sleep_hours":          sleep_hours.round(1),
    "extracurricular":      extracurricular,
    "peer_support":         peer_support.round(1),
    "motivation_score":     motivation_score.round(1),
    "resource_usage":       resource_usage.round(1),
    "at_risk":              at_risk
})

df.to_csv("student_data.csv", index=False)
print(f"✅ Dataset generated: {len(df)} rows  |  At-Risk: {at_risk.sum()} ({at_risk.mean()*100:.1f}%)")

# ── Feature / target split ────────────────────────────────────────────────────
FEATURES = [
    "attendance", "study_time", "past_scores", "assignment_completion",
    "failures", "absences", "participation", "sleep_hours",
    "extracurricular", "peer_support", "motivation_score", "resource_usage"
]

X = df[FEATURES]
y = df["at_risk"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# ── Scale ─────────────────────────────────────────────────────────────────────
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

# ── Logistic Regression ───────────────────────────────────────────────────────
lr = LogisticRegression(max_iter=500, random_state=42, class_weight="balanced")
lr.fit(X_train_s, y_train)
y_pred_lr = lr.predict(X_test_s)

# ── Random Forest ─────────────────────────────────────────────────────────────
rf = RandomForestClassifier(
    n_estimators=200, max_depth=8, random_state=42, class_weight="balanced"
)
rf.fit(X_train, y_train)
y_pred_rf = rf.predict(X_test)

# ── Metrics ───────────────────────────────────────────────────────────────────
def compute_metrics(y_true, y_pred, name):
    cm = confusion_matrix(y_true, y_pred)
    return {
        "model":     name,
        "accuracy":  round(accuracy_score(y_true, y_pred) * 100, 2),
        "precision": round(precision_score(y_true, y_pred, zero_division=0) * 100, 2),
        "recall":    round(recall_score(y_true, y_pred, zero_division=0) * 100, 2),
        "f1":        round(f1_score(y_true, y_pred, zero_division=0) * 100, 2),
        "confusion_matrix": cm.tolist()
    }

metrics_lr = compute_metrics(y_test, y_pred_lr, "Logistic Regression")
metrics_rf = compute_metrics(y_test, y_pred_rf, "Random Forest")

print("\n── Logistic Regression ──────────────────────────────")
print(classification_report(y_test, y_pred_lr, target_names=["Not At-Risk", "At-Risk"]))
print("── Random Forest ────────────────────────────────────")
print(classification_report(y_test, y_pred_rf, target_names=["Not At-Risk", "At-Risk"]))

# ── Save artefacts ────────────────────────────────────────────────────────────
# Artefacts saved: model_lr.pkl, model_rf.pkl, scaler.pkl, metrics.json
# Artefacts are basically the trained models, the scaler for feature transformation,
# and the computed metrics for display on the webpage
with open("model_lr.pkl",  "wb") as f: pickle.dump(lr,     f)
with open("model_rf.pkl",  "wb") as f: pickle.dump(rf,     f)
with open("scaler.pkl",    "wb") as f: pickle.dump(scaler, f)

all_metrics = {"logistic_regression": metrics_lr, "random_forest": metrics_rf}
with open("metrics.json", "w") as f:
    json.dump(all_metrics, f, indent=2)

print("\n✅ Saved: model_lr.pkl | model_rf.pkl | scaler.pkl | metrics.json")

# ── Prediction helper (used by main.js via subprocess) ───────────────────────
def predict(input_dict, model_type="rf"):
    """
    input_dict: dict with all FEATURES keys
    Returns: { "label": "At Risk" | "Not At Risk", "probability": float }
    """
    row = pd.DataFrame([{f: input_dict.get(f, 0) for f in FEATURES}])
    if model_type == "lr":
        row_s = scaler.transform(row)
        prob  = lr.predict_proba(row_s)[0][1]
        pred  = lr.predict(row_s)[0]
    else:
        prob  = rf.predict_proba(row)[0][1]
        pred  = rf.predict(row)[0]
    return {
        "label":       "At Risk" if pred == 1 else "Not At Risk",
        "probability": round(float(prob) * 100, 1)
    }

if __name__ == "__main__":
    import sys, json as _json
    if len(sys.argv) > 1:
        data = _json.loads(sys.argv[1])
        model_type = data.pop("model_type", "rf")
        result = predict(data, model_type)
        print(_json.dumps(result))
